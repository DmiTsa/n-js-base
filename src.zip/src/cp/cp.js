const spawnChildProcess = async (args) => {
    // Write your code here
};

spawnChildProcess();