// env.js - реализовать функцию, которая анализирует переменные окружения с префиксом RSS_ и выводит их на консоль в формате RSS_name1=value1; RSS_имя2=значение2
const parseEnv = () => {
  // Write your code here
};

parseEnv();
