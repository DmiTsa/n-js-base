const write = async () => {
    // Write your code here 
};

await write();