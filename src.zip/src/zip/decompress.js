const decompress = async () => {
    // Write your code here 
};

await decompress();